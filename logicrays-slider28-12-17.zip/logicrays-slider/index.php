<?php
/**
 * Plugin Name:       LogicRays Slider
 * Plugin URI:        http://logicrays.com
 * Description:       Easy to use slider with shortcode
 * Version:           1.0
 * Author:            logicrays
 * Author URI:        http://logicrays.com
 * Text Domain:       Slider with Shortcode * 
 */
 
if ( ! defined( 'WPINC' ) ) {
	die;
}
function activate_wp_lr_slider_plugin(){
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-lr-slider-plugin-activate.php';
	Wp_Lr_Slider_Plugin_Activate::activate();
}
function deactivate_wp_lr_slider_plugin(){
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-lr-slider-plugin-deactivate.php';
	Wp_Lr_Slider_Plugin_Deactivate::deactivate();
}
register_activation_hook( __FILE__, 'activate_wp_lr_slider_plugin' );
register_deactivation_hook( __FILE__, 'deactivate_wp_lr_slider_plugin' );

require_once plugin_dir_path( __FILE__ ) . 'class-wp-lr-slider-shortcode.php';

new Wp_Lr_Slider_Shortcode();