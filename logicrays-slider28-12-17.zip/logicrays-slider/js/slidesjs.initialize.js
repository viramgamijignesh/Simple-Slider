// jQuery(window).load(function() {
//   jQuery('.flexslider').flexslider({
//     animation: "slide",
//     controlsContainer: jQuery(".custom-controls-container"),
//     customDirectionNav: jQuery(".custom-navigation a")
//   });
// });
// jQuery(document).ready(function() {
//     jQuery('.image-frame').hover(function(){
// 		jQuery('.image-caption',this).slideToggle('slow');
// 	}, function(){
// 		jQuery('.image-caption',this).slideToggle('slow');
//     });
// });