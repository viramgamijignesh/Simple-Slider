<?php

	function lr_simple_slider_field($field)
	{
		$allowed_fields = apply_filters(
			'post-content-allowed-fields',
			array(
				'post_author',
				'post_date',
				'post_date_gmt',
				'post_content',
				'post_title',
				'post_excerpt',
				'post_status',
				'comment_status',
				'ping_status',
				'post_name',
				'to_ping',
				'pinged',
				'post_modified',
				'post_modified_gmt',
				'post_content_filtered',
				'post_parent',
				'guid',
				'menu_order',
				'post_type',
				'post_mime_type',
				'comment_count'
			)
		);

		foreach (array( $field, 'post_' . $field ) as $field_name) {
			if (in_array($field_name, $allowed_fields)) {
				return $field_name;
			}
		}

		return false;
	}
	function lr_simple_slider_status($status = '', $default_status = 'publish')
	{
		$valid_fields = array_intersect(split_comma($status), get_post_stati());

		if (empty($valid_fields)) {
			$valid_fields[] = $default_status;
		}

		return $valid_fields;
	}


	function lr_simple_slider_shortcode_attributes($attributes = array())
	{
		$default_attributes = array(
			'id'        => 0,
			'autop'     => true,
			'shortcode' => true,
			'field'     => 'post_content',
			'status'    => 'publish'
		);

		$attributes = shortcode_atts(
			array_merge(
				$default_attributes,
				apply_filters('post-content-default-attributes', $default_attributes)
			),
			$attributes,
			'post-content'
		);

		return array(
			'id'        => (int)$attributes['id'],
			'autop'     => is_yes($attributes['autop']),
			'shortcode' => is_yes($attributes['shortcode']),
			'field'     => lr_simple_slider_field($attributes['field']),
			'status'    => lr_simple_slider_status($attributes['status'])
		);
	}
	if (! function_exists('is_yes')) {
		function is_yes($arg)
		{
			if (is_string($arg)) {
				$arg = strtolower($arg);
			}
			return in_array($arg, array( true, 'true', 'yes', 'y', '1', 1 ), true);
		}
	}

	if (! function_exists('split_comma')) {
		function split_comma($csv)
		{
			return array_map('trim', explode(',', $csv));
		}
	}



class Wp_Lr_Slider_Shortcode {

    private $options_general;

    public function __construct() {
        if ( is_admin() ) {
            add_action( 'init', array( $this,'simple_register_slider' ) );
         }
        add_action( 'wp_enqueue_scripts', array( $this, 'lr_simple_slider_scripts' ) );
       
        // add_action( 'wp_enqueue_scripts', array( $this, 'lr_simple_slider_styles' ) );
        add_shortcode('simple_image_slider', array( $this, 'lr_simple_slider_shortcode' ) );
        add_filter('manage_edit-slider_columns', array( $this, 'simple_set_custom_edit_slider_columns' ) );
        add_action('manage_slider_posts_custom_column', array( $this, 'simple_custom_slider_column' ), 10, 2 ); 
        add_action( 'init', array( $this, 'remove_text_editor' ) );
        add_action('admin_menu', array( $this, 'lr_simple_slider_setting_tab') );
        add_action( 'admin_init', array( $this, 'lr_simple_slider_setting' ) );
        add_action('wp_footer', array( $this, 'print_my_script' ) );
        require_once plugin_dir_path( __FILE__ ) . 'meta-box-class/cass-lr-admin-metabox.php';       
    }

    public function remove_text_editor() {
    
      remove_post_type_support( 'slider', 'editor' );
    //remove_meta_box( 'submitdiv', 'slider', 'side' );
    }
    public function simple_register_slider() {

    $labels = array(
      'name' => 'All Slide',
      'menu_name' => 'Simple Slider',
      'add_new' => 'Add New Slider',
      'add_new_item' => 'Add New Slider',
      'edit_item' => 'Edit Slider'
      
    );
    $args = array(
      
      'labels' => $labels,
      'hierarchical' => true,
      'description' => 'Slideshows',
      'supports' => array('title', 'editor'),
      'public' => true,
      'show_ui' => true,
      'show_in_menu' => true,
      'show_in_nav_menus' => true,
      'publicly_queryable' => true,
      'exclude_from_search' => false,
      'has_archive' => true,
      'query_var' => true,
      'can_export' => true,
      'rewrite' => true,
      'capability_type' => 'post'
    );
    register_post_type('slider', $args);

  }
  public function lr_simple_slider_setting_tab() {

   add_submenu_page( 'edit.php?post_type=slider', 'Slider Setting Page', 'Setting', 'manage_options', 'general', array($this,'my_custom_submenu_page_callback') ); 

  }
	function my_custom_submenu_page_callback() {
	?>
	<div class="wrap cust-postbox ">
	<h2>Slider Setting Page</h2>
	<form action="options.php" method="post">
	  <?php
	  if ( function_exists('wp_nonce_field') ) 
	   wp_nonce_field('plugin-name-action_' . "yep"); 
	  ?>
	  <?php settings_fields('lr_options'); ?>
	  <?php do_settings_sections(__FILE__); ?>
	  <p class="submit">
	  <input name="Submit" type="submit" class="button-primary" value="<?php esc_attr_e('Save Changes'); ?>" />
	  </p>
	</form>
	</div> <?php
	}
	public function lr_simple_slider_setting() { 

		register_setting('lr_options', 'lr_options', 'lr_options_validate' );
		add_settings_section('main_section', 'Caption Settings', array($this,'lr_setting_section_desc'), __FILE__);
		add_settings_field('text_caption', 'Enable / Disable', array($this,'lr_caption_enable'), __FILE__, 'main_section');     
		add_settings_field('text_align', 'Select Caption Alignment', array($this,'lr_caption_alignment'), __FILE__, 'main_section');
		add_settings_field('img_height', 'Image Height', array($this,'lr_img_height_fn'), __FILE__, 'main_section');
		add_settings_field('img_width', 'Image Width', array($this,'lr_img_width_fn'), __FILE__, 'main_section');
		add_settings_field('pause_time', 'Slideshow Speed', array($this,'lr_pause_time_fn'), __FILE__, 'main_section');
		add_settings_field('change_speed', 'Animation Speed', array($this,'lr_change_speed_fn'), __FILE__, 'main_section');
		add_settings_field('navigate_by', 'Navigate By', array($this,'lr_navigate_by_fn'), __FILE__, 'main_section');
		//add_settings_field('slider_effects', 'Slider Effects', array($this,'lr_slider_effects_fn'), __FILE__, 'main_section');
		
	}

	public function  lr_setting_section_desc() {

		echo '';

	}
	// TEXTBOX - Name: plugin_options[text_string]
	function lr_img_height_fn() {
		$options = get_option('lr_options');
		echo "<input id='lr_img_height' name='lr_options[lr_img_height]' size='40' type='number' value='{$options['lr_img_height']}' />&nbsp; px";
	}
	function lr_img_width_fn() {
		$options = get_option('lr_options');
		echo "<input id='lr_img_width' name='lr_options[lr_img_width]' size='40' type='number' value='{$options['lr_img_width']}' />&nbsp; px";
	}
	function lr_pause_time_fn() {
		$options = get_option('lr_options');
		echo "<input id='lr_pause_time_fn' name='lr_options[lr_pause_time]' size='40' type='number' value='{$options['lr_pause_time']}' /> &nbsp; Millisecond";
	}
	function lr_change_speed_fn() {
		$options = get_option('lr_options');
		echo "<input id='lr_change_speed_fn' name='lr_options[lr_change_speed]' size='40' type='number' value='{$options['lr_change_speed']}' />&nbsp; Millisecond";
	}
	// DROP-DOWN-BOX - Name: lr_options[dropdown1]
	public function  lr_caption_alignment() {

	  $options = get_option('lr_options');
	  $items = array("Left", "Center", "Right");
	  echo "<select id='text_align' name='lr_options[text_align]'>";
	  foreach($items as $item) {
		$selected = ($options['text_align']==$item) ? 'selected="selected"' : '';
		echo "<option value='$item' $selected>$item</option>";
	  }
	  echo "</select>";

	}
	// DROP-DOWN-BOX - Name: lr_options[dropdown1]
	public function  lr_navigate_by_fn() {

	  $options = get_option('lr_options');
	  $items = array("Dots", "No Navigation");
	  echo "<select id='navigate_by' name='lr_options[navigate_by]'>";
	  foreach($items as $item) {
		$selected = ($options['navigate_by']==$item) ? 'selected="selected"' : '';
		echo "<option value='$item' $selected>$item</option>";
	  }
	  echo "</select>";

	}
	// DROP-DOWN-BOX - Name: lr_options[dropdown1]
	// public function  lr_slider_effects_fn() {

	//   $options = get_option('lr_options');
	//   $items = array("Fade", "Slice Horizontal","Cube Vertical","Slice Vertical","Scale Out","Scale In","Block Scale","Kaleidoscope","fan","Blind Horizontal","Blind Vertical","Random");
	//   echo "<select id='slider_effects' name='lr_options[slider_effects]'>";
	//   foreach($items as $item) {
	// 	$selected = ($options['slider_effects']==$item) ? 'selected="selected"' : '';
	// 	echo "<option value='$item' $selected>$item</option>";
	//   }
	//   echo "</select>";

	// }
	public function lr_caption_enable() {

	  $options = get_option('lr_options');
	  if($options['text_caption']) { $checked = ' checked="checked" '; }
	  echo "<input ".$checked." id='text_caption' name='lr_options[text_caption]' type='checkbox' />";

	}

	public function lr_options_validate($input) {
	  // Check our textbox option field contains no HTML tags - if so strip them out
	  $input['text_string'] =  wp_filter_nohtml_kses($input['text_string']);  
	  return $input; // return validated input
	}
  
	public function lr_simple_slider_scripts() {

	  wp_enqueue_script('jquery');
	  wp_register_script('jquery.flexslider', plugins_url('js/jquery.flexslider.js',(__FILE__)));
	  wp_enqueue_script('jquery.flexslider');

	  wp_register_script('slidesjs.initialize', plugins_url('js/slidesjs.initialize.js',(__FILE__)));
	  wp_enqueue_script('slidesjs.initialize');

	  wp_register_style('css-flexslider', plugins_url('css/flexslider.css', (__FILE__)));
	  wp_enqueue_style('css-flexslider'); 

	  

	}
	public function simple_custom_slider_column($column, $post_id) {

	  $post_id = get_the_ID(); 
	  $slider_meta = get_post_meta($post_id, "_simple_slider_meta", true);
	  $slider_meta = ($slider_meta != '') ? json_decode($slider_meta) : array();
	  switch ($column){
		  case 'slider_shortcode':
			  echo "[simple_image_slider id=$post_id]";
		  break;
	  }
	}
	// public function lr_simple_slider_styles() {
	  
	  
	// }

	public function simple_set_custom_edit_slider_columns($columns) {

	  return $columns     
	  + array('slider_shortcode' => __('Shortcode'));
	  
	}

	public function print_my_script() {
		global $add_my_script, $ss_atts;
		$slider_caption = get_option( 'lr_options' );
			if($slider_caption['lr_pause_time'] !='')
			{
				$speed = $slider_caption['lr_pause_time'];
			}
			else{
				$speed = '4000';
			}
			if($slider_caption['lr_change_speed'] !='')
			{
				$animationspeed = $slider_caption['lr_change_speed'];
			}else{
				$animationspeed = '3000';
			}
			$controlNav = $slider_caption['navigate_by'];
			if($controlNav == 'No Navigation')
			{
				$controlNav1 .= "false";
			}
			else{
				$controlNav1 .= "true";
			}
			echo "<script type=\"text/javascript\">
	jQuery(document).ready(function($) {
		
		jQuery('.flexslider').flexslider({
			animation: 'slide',
			slideshowSpeed: ".$speed.",
			animationSpeed: ".$animationspeed.",
			controlNav: ".$controlNav1."
		});
	});
	</script>";
			wp_print_scripts('flexslider');
		
	}
	public function lr_simple_slider_shortcode($attributes, $shortcode_content = null, $code = '') {
	
	global $post;
	$content = '';
	$attributes = lr_simple_slider_shortcode_attributes($attributes);

	if ($attributes['field'] && get_the_ID() !== $attributes['id'] && in_array(get_post_status($attributes['id']), $attributes['status'])) {
	  $original_post = $post;

	  $post = get_post($attributes['id']);

	  if (is_a($post, 'WP_Post')) {
		 
		 $data = (get_post_meta($post->ID));
		 
		 $data = $data['re_'];
		
		 $data = implode(' ', $data);      
		 $unserialize_data = unserialize($data);             
		 $slider_caption = get_option( 'lr_options' );
		 $text_caption = $slider_caption['text_caption'];
		 $caption_align = $slider_caption['text_align'];
		 if($slider_caption['lr_img_height'] !=''){
		 	$lr_img_height1 = $slider_caption['lr_img_height'];
		 }else{
		 	$lr_img_height = 'auto';
		 }
		 if($slider_caption['lr_img_width']!=''){
		 	$lr_img_width = $slider_caption['lr_img_width'];
		 }else{
		 	$lr_img_width = 'auto';
		 }
		 
		 
		   
			
		 $content .= '<div class="img-container">';   
		 // $content .= '<div class="image-frame">';

		 $content .= '<div class="flexslider">';
		 $content .= '<ul class="slides">';        
		 foreach ($unserialize_data as $value) {
			 $image_url = $value['image_field_id']['url'];
			 $content .= '<li>';
			 if($text_caption == 'on') {
				$content .= '<div class="'.$caption_align.'">'.$value['re_textarea_field_id'].'</div>';
			 } 
			 $content .= '<img style="height:'.$lr_img_height.'px width:'.$lr_img_width.'px" src="'.$image_url.'" />';
			 // if($slider_caption == 'yes') {
			 //    $content .= '<div class="image-caption">'.$value['re_textarea_field_id'].'</div>';
			 // } 
			 
			 $content .= '</li>';
				  
		 }
		  
		  $content .= '</ul>';
		  $content .= '</div>';
		  // $content .= '</div>';

		  // $content .= '<div class="custom-navigation">';
		  // $content .= '<img src="'.plugin_dir_url( __FILE__ ).'meta-box-class/images/left1.png" />';                 
		  // $content .= '<img src="'.plugin_dir_url( __FILE__ ).'meta-box-class/images/right1.png" />';
		  // $content .= '</div>'; 
		 
	  }

	  $post = $original_post;
	}

	return $content;
	}


}
