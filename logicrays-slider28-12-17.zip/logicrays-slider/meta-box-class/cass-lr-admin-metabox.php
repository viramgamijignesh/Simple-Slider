<?php
class Lr_Admin_Metabox {

  public $prefix = 'ba_re_';

  public function __construct() {

    
    
    add_filter('manage_edit-slider_columns', array( $this,'simple_set_custom_edit_slider_columns' ) );
    add_action('manage_slider_posts_custom_column', array( $this,'simple_custom_slider_column'), 10, 2 );  

  }

  
  public function simple_set_custom_edit_slider_columns($columns) {

    return $columns   
    + array('slider_shortcode' => __('Shortcode'));
    
  }
  public function simple_custom_slider_column($column, $post_id) {

    switch ($column){
      case 'slider_shortcode':
        echo "[simple_image_slider id=$post_id]";
      break;
    }
  }


}
require_once plugin_dir_path( __FILE__ ) . 'my-meta-box-class.php';  


$config2 = array(
  'id'             => 'demo_meta_box2',          // meta box id, unique per meta box
  'title'          => 'Advanced Meta Box fields',          // meta box title
  'pages'          => array('slider'),      // post types, accept custom post types as well, default is array('post'); optional
  'context'        => 'normal',            // where the meta box appear: normal (default), advanced, side; optional
  'priority'       => 'high',            // order of meta box: high (default), low; optional
  'fields'         => array(),            // list of meta fields (can be added by field arrays)
  'local_images'   => false,          // Use local or hosted images (meta box images for add/remove)
  'use_with_theme' => false          //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
);

$my_meta2 =  new AT_Meta_Box($config2);


$repeater_fields[] = $my_meta2->addText($prefix.'re_text_field_id',array('name'=> 'Slider Title '),true);
$repeater_fields[] = $my_meta2->addTextarea($prefix.'re_textarea_field_id',array('name'=> 'Slider Content '),true);

$repeater_fields[] = $my_meta2->addImage($prefix.'image_field_id',array('name'=> 'Slider Image '),true);

$my_meta2->addRepeaterBlock($prefix.'re_',array(
  'inline'   => true, 
  'name'     => '',//This is a Repeater Block
  'fields'   => $repeater_fields, 
  'sortable' => true
));


$my_meta2->Finish();  