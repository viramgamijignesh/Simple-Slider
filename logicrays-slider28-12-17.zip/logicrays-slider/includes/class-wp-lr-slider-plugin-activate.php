<?php
class Wp_Lr_Slider_Plugin_Activate {	

	public static function activate() {
	
		
	
	}
  
}