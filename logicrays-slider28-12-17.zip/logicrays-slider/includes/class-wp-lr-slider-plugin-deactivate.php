<?php
class Wp_Lr_Slider_Plugin_Deactivate {
	public static function deactivate() {

	}
}